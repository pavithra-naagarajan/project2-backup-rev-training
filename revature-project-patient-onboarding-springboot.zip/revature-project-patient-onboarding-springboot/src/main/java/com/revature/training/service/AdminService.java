package com.revature.training.service;

public interface AdminService {

}
