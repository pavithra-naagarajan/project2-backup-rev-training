export class Patient {
    patientId? : number;
	password? :string;
	patientName? :string;
	gender? :string;
	patientAge? :number;
	mobileNumber? :string;
	mailId? :string;
	address? :string;
	
}
