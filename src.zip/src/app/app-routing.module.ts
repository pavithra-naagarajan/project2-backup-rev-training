import { NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';
import { AppComponent } from './app.component';
import { LoginComponent } from './components/login/login.component';
import { PatientListComponent } from './components/patient-list/patient-list.component';
import { PatientUpdateComponent } from './components/patient-update/patient-update.component';
import { PatientSignUpComponent } from './components/patientSignUp/patientSignUp.component';
import { ViewProfileComponent } from './components/view-profile/view-profile.component';
import { PatientOperationsComponent } from './patient-operations/patient-operations.component';


const routes: Routes = 
[
  { path: '', component:PatientListComponent },
  { path: 'signUp', component:PatientSignUpComponent },
  { path: 'login', component:LoginComponent },
  { path: 'viewProfile/:patientId', component:PatientListComponent },
  { path: 'signUp/patientId', component:PatientSignUpComponent },
  { path: 'viewProfile', component:ViewProfileComponent },
  { path: 'update/:patientId', component:PatientUpdateComponent },
  { path: 'patientFunc/:patientId', component:PatientOperationsComponent }
  

  // { path: 'addProduct/:productId', component:ProductAddComponent } 
];


@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule { }
